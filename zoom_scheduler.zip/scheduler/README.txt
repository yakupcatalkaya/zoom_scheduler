







________________________________________Welcome to Zoom Scheduler V1________________________________________________
                                                                                                  Created by mrjacob|
 												                    |
      														    |
1) Before opening the program, you should change the context of 'your_info.txt' file.                               |
2) In the 'your_info.txt' file, there are 5 lines.                                                                  |
3) For each line, you should write your information after deleting the corresponding line in the same order.        |
4) For example, replace "bilkent mail" with "xx@xx.bilkent.edu.tr".                                                 |
5) After replacement, save 'your_info.txt' file and then run the zoom.exe program.                                  |
6) In the zoom.exe, you will see a prompt that asks you where the program get your information.                     |
7) "file" means you ask program to take the information from 'your_info.txt' file.                                  |
8) "typing" means you want to type your information by hand.                                                        |
9) If you want to choose "typing", write "typing" and press enter.                                                  |
10) Then, the program will ask you your srs id, srs password, mail address, mail password, and telephone number.    |
11) After writing each to program, press enter.                                                                     |
12) After the program gets your information either from file or from your typing, it will start automatically.      |
13) Make sure that you have an active whatsapp web account in your web browser.                                     |
                                                                                                                    |
____________________________________________________________________________________________________________________|

